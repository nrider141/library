class EggPlant extends Plant {
    constructor(height, imgSrc, growRate) {
        super(height, imgSrc, growRate);
    }
}